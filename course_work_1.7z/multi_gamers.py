import json
import random
import requests as requests
from Gamer import *


def read_file(url):
    """
    Выбирает случайное слово из списка слов для игры
    :param url: ссылка на список слов
    :return: выбранное слово для текущей игры
    """

    response = requests.get(url)
    words_list = response.json()
    random.shuffle(words_list)

    return words_list[0]


def print_results(list_):
    """
    Подведение итогов игры, вывод победителя
    :param list_: список игроков

    """

    winners_number = 0
    max_score = 0
    winner = None

    print("Игра окончена\n======")

    for g in list_:
        print(f"Игрок {list_.index(g) + 1} {g.name} - {g.score}")

        if g.score > max_score:
            max_score = g.score
            winner = g
            winners_number = list_.index(g) + 1

    print(f"======\nПобедил игрок {winners_number} {winner.name}")


with open('russian.txt', 'r', encoding="windows-1251") as file:
    russian_words = file.readlines()

gamers_amount = int(input("Добро пожаловать в игру!\nВведите количество игроков\n"))
gamers = []
results = {"Users": {}, "Word": read_file("https://jsonkeeper.com/b/S3F0"), "Words": []}

for i in range(gamers_amount):
    gamers.append(Gamer(input(f"Введите имя {i + 1}-го игрока\n")))
    results["Users"][i] = gamers[i].name

stop_words = ["stop", "стоп"]
is_game_stopped = False

print(f"Игра начинается!\nВаше слово на эту игру:\n{results['Word'].upper()}\n")

while not is_game_stopped:
    print(f"======\nНачало раунда\n{results['Word']}")

    for gamer in gamers:
        is_word_correct = True
        check_letters_word = results['Word']  # переменная для проверки использования букв,
        # входящих в выпавшее в игре слово

        users_word = input(f"Ходит игрок {gamer.name}\n").lower()

        if users_word in stop_words:
            is_game_stopped = True
            break

        elif users_word in results["Words"]:
            print("Такое слово уже было")
            continue

        elif (users_word + "\n") not in russian_words:
            print("В русском языке нет такого слова")
            continue

        else:
            for letter in users_word:
                if letter in check_letters_word.lower():
                    check_letters_word = check_letters_word.replace(letter, '*', 1)

                else:
                    print("Использованы недопустимые буквы")
                    is_word_correct = False
                    break

            if is_word_correct:
                gamer.words.append(users_word)
                results["Words"].append(users_word)
                gamer.score += len(users_word)
                print("Принято")
                continue

print_results(gamers)

file = open("winners.json", "w")
json.dump(results, file)
file.close()
print("======\nДанные записаны в файл")
