class Gamer:
    def __init__(self, name):
        self.name = name
        self.score = 0
        self.words = []
